Theorem invalid : False. Proof. exact I. Qed.
